$.ajax({
    url: 'https://api.cricapi.com/v1/cricScore?apikey=0f765985-e480-4b29-97c6-638f0263b6d2',
    method: 'GET',
    dataType: 'json',
    success: function (response) {
        for (var i = 0; i <= 20; i++) {
            var t1Img = response.data[i].t1img;
            var t2Img = response.data[i].t2img;
            var t1Logo = t1Img ? `<img src="${t1Img}" class="mx-2">` : '';
            var t2Logo = t2Img ? `<img src="${t2Img}" class="mx-2">` : '';
            
            $('#allMatch').append(`
                <div class="col-md-4 my-3" id="allCard">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body">
                            <h5 class="card-title text-center">${response.data[i].matchType}</h5>
                            <p class="card-text text-center">${t1Logo}${response.data[i].t1}</p>
                            <p class="card-text text-center">vs</p>
                            <p class="card-text text-center" id="t2">${t2Logo}${response.data[i].t2}</p>
                            <div class="text-center">Date-time: ${response.data[i].dateTimeGMT}</div>
                            <h6 class="note text-center mt-3">Note: All dates & times are in GMT</h6>
                        </div>
                    </div>
                </div>
            `);
        }
    },
    error: function (xhr, status, error) {
        console.log("AJAX Error:", error);
    }
});