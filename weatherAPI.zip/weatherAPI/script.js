var searchBox = document.querySelector('#cityName');
var search = document.querySelector('.searchBtn');
var apiKey = '0303ae07551b37a516d75dc56eeb047d';
// if(){
async function weather(city){

    var url = 'http://api.openweathermap.org/geo/1.0/direct?q='+ city +'&appid=0303ae07551b37a516d75dc56eeb047d';

    const result = await fetch(url);
    var data = await result.json();
    if (result.status !== 404){
        document.querySelector('.error').style.display = 'block';
        document.querySelector('.weather').style.display = "none";
    }else{
        // console.log(data);
        var lon = data[0].lon;
        var lat = data[0].lat;

        var weatherUrl = 'https://api.openweathermap.org/data/2.5/weather?lat='+ lat +'&lon='+ lon +'&appid=0303ae07551b37a516d75dc56eeb047d&units=metric';
        const response = await fetch(weatherUrl);

        var resp = await response.json();
        console.log(resp);
        document.querySelector('#image').src = 'https://openweathermap.org/img/wn/'+ resp.weather[0].icon +'@2x.png';
        document.querySelector('.condition').innerHTML = resp.weather[0].main;
        document.querySelector('.city').innerHTML = data[0].name;
        document.querySelector('.tempreture').innerHTML = Math.round(resp.main.temp) + '°c';
        document.querySelector('.air').innerHTML = resp.wind.speed + " km/h";
        document.querySelector('.press').innerHTML = resp.main.pressure + " mb";
        document.querySelector('.hum').innerHTML = resp.main.humidity + "%";

        document.querySelector('.weather').style.display = "block";
        document.querySelector('.error').display = 'none';
    }
}

search.addEventListener('click',()=>{
    weather(searchBox.value);

})

